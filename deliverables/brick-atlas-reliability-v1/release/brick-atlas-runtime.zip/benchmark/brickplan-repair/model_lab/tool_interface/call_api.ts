// Native Responses function calling only. No extraction from assistant prose.
import {existsSync,readFileSync,openSync,closeSync,unlinkSync} from 'node:fs';
import {resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {atomicJson} from '../../../core/budget';
const root=resolve(import.meta.dirname,'../../../..');
const request=JSON.parse(readFileSync(0,'utf8'));
const body=request.body;
const chat=request.transport==='chat-completions';
const ids=['openai/gpt-6.1-sol','google/gemini-4-argon','anthropic/claude-sonnet-5.5'];
if(request.protocol!=='visual-native-tools/2'||!ids.includes(body?.model)||(!chat&&body.store!==false)||body.parallel_tool_calls!==false||(chat?body.max_tokens:body.max_output_tokens)!==2048||chat!==body.model.startsWith('google/'))throw Error('Invalid native-tool request');
if(body.tool_choice!==(body.model.startsWith('anthropic/')?'auto':'required'))throw Error('Invalid tool choice for provider');
if(!Array.isArray(body.tools)||body.tools.length!==4||!body.tools.every((t:any)=>{const f=chat?t.function:t;return t.type==='function'&&f.strict===true&&f.parameters.additionalProperties===false;}))throw Error('Missing strict tool schemas');
let images=0;
const countable=JSON.stringify(body,(key,value)=>{
  if(key==='image_url'&&typeof value==='string'||key==='url'&&typeof value==='string'&&value.startsWith('data:image/png;base64,')){
    if(typeof value!=='string'||!value.startsWith('data:image/png;base64,'))throw Error('Only inline PNG inputs enabled');
    images++;return '<PNG>';
  }
  return value;
});
const bytes=Buffer.byteLength(countable)+2048;
if(bytes>50000||images<7||images>9)throw Error('Input exceeds tool pilot limits');
const catalogueResponse=await fetch('https://openrouter.ai/api/v1/models',{signal:AbortSignal.timeout(20000)});
if(!catalogueResponse.ok)throw Error('Model catalogue unavailable');
const catalog=await catalogueResponse.json() as any;
const entry=catalog.data.find((m:any)=>m.id===body.model);
if(!entry?.architecture?.input_modalities.includes('image')||!['tools','tool_choice','structured_outputs'].every(p=>entry.supported_parameters.includes(p))||!(Number(entry.pricing.prompt)<=.000002)||!(Number(entry.pricing.completion)<=.00001))throw Error('Model capability or pricing mismatch');
if(!process.env.OPENROUTER_API_KEY)process.loadEnvFile(resolve(root,'.env'));
if(!process.env.OPENROUTER_API_KEY)throw Error('Missing API key');
const path=resolve(root,'benchmark/.runtime/pilot.lock');closeSync(openSync(path,'wx',0o600));
let charge:any;
const ledgerPath=resolve(root,'benchmark/.runtime/campaign-ledger.json');
const ledger=JSON.parse(readFileSync(ledgerPath,'utf8'));
const persist=()=>atomicJson(ledgerPath,ledger);
try {
  const auth=JSON.parse(readFileSync(resolve(root,'deliverables/brickplan-model-lab/budget-authorization.json'),'utf8'));
  const test=JSON.parse(readFileSync(resolve(root,'deliverables/brickplan-model-lab/tool-calling/budget.json'),'utf8'));
  if(auth.scope!=='model-lab-2026-10-15'||auth.additionalCapUSD!==4||auth.cumulativeCeilingUSD!==auth.baselineSpentUSD+4||test.additionalCapUSD!==1.5||test.parentAuthorization!==auth.scope||test.cumulativeCeilingUSD>Math.min(auth.cumulativeCeilingUSD,test.baselineSpentUSD+1.5))throw Error('Invalid budget configuration');
  if(ledger.charges.some((c:any)=>c.status!=='settled'))throw Error('Unsettled charge; stopped');
  const ceiling=(bytes+images*16384)*.000002+2048*.00001+images*.005;
  const committed=ledger.charges.reduce((s:number,c:any)=>s+(c.actual??c.reserved),0);
  if(committed+ceiling>Math.min(auth.cumulativeCeilingUSD,test.cumulativeCeilingUSD))throw Error('Budget limit reached before request');
  charge={id:randomUUID(),model:body.model,reserved:ceiling,actual:null,status:'pending',authorization:auth.scope,experiment:test.scope,createdAt:new Date().toISOString()};
  ledger.charges.push(charge);persist();
  const start=performance.now();
  const response=await fetch('https://openrouter.ai/api/v1/'+(chat?'chat/completions':'responses'),{
    method:'POST',signal:AbortSignal.timeout(90000),
    headers:{Authorization:`Bearer ${process.env.OPENROUTER_API_KEY}`,'Content-Type':'application/json','X-OpenRouter-Title':'Brick Atlas native tool interface'},
    body:JSON.stringify(body),
  });
  const data=await response.json() as any;
  atomicJson(resolve(root,`deliverables/brickplan-model-lab/tool-calling/transport-${charge.id}.json`),{httpStatus:response.status,id:data.id??null,status:data.status??null,usage:data.usage??null,outputTypes:(data.output??[]).map((x:any)=>x.type),errorCode:data.error?.code??null,errorMessage:typeof data.error?.message==='string'?data.error.message.slice(0,500).replace(/sk-[A-Za-z0-9_-]+/g,'[REDACTED]'):null});
  if(!response.ok)throw Error(`OpenRouter HTTP ${response.status}; no automatic retry`);
  if(!data.id||typeof data.usage?.cost!=='number'||!Number.isFinite(data.usage.cost)||data.usage.cost<0)throw Error('Missing settled cost; reconciliation required');
  charge.actual=data.usage.cost;charge.generationId=data.id;charge.status=data.usage.cost<=ceiling?'settled':'uncertain';persist();
  if(charge.status!=='settled')throw Error('Provider exceeded reservation');
  const message=chat?data.choices?.[0]?.message:undefined;
  const rawToolCalls=chat?(message?.tool_calls??[]):(data.output??[]).filter((x:any)=>x.type==='function_call');
  const output=chat?rawToolCalls.map((t:any)=>({type:'function_call',call_id:t.id,name:t.function?.name,arguments:t.function?.arguments})):data.output??[];
  console.log(JSON.stringify({id:data.id,provider:data.provider??'unknown',content:'',output,rawToolCalls,assistantMessage:message,rawResponse:data,cost:data.usage.cost,promptTokens:data.usage.input_tokens??data.usage.prompt_tokens,completionTokens:data.usage.output_tokens??data.usage.completion_tokens,reasoningTokens:data.usage.output_tokens_details?.reasoning_tokens??data.usage.completion_tokens_details?.reasoning_tokens??0,latencyMs:Math.round(performance.now()-start),finishReason:data.status??data.choices?.[0]?.finish_reason}));
} catch(e) {
  if(charge)atomicJson(resolve(root,`deliverables/brickplan-model-lab/tool-calling/failure-${charge.id}.json`),{chargeId:charge.id,error:e instanceof Error?e.message.slice(0,200):'Unknown error'});
  if(charge?.status==='pending'){charge.status='uncertain';persist();}
  throw e;
} finally {unlinkSync(path);}
