"""Summarize every outcome without mixing format, service, geometry and recovery."""
import json
from collections import Counter
from dynamic_arena import OUT as ARENA_OUT
from dynamic_arena.transport import write_json
from unified_agent import OUT


def audit(result):
    folder=ARENA_OUT/'runs'/result['arenaRunId'];log=json.loads((folder/'log.json').read_text())
    codes=Counter();invalid=[];truncated=[];observations=[]
    for call in log['calls']:
        number=call['index'];codes[call.get('environmentOutput',{}).get('code',call.get('error',{}).get('code','unknown'))]+=1
        if (call.get('providerReceipt') or {}).get('finishReason')=='length':truncated.append(number)
        if call.get('modelOutput',{}).get('tool')=='invalid':
            try:
                value=json.loads(call.get('modelOutputRaw',''));reason='schema_or_parameter'
                if isinstance(value,dict):
                    args=value.get('args',{})
                    if value.get('tool')=='observe':
                        if 'rotateDegrees' not in args:reason='missing_rotateDegrees'
                        elif args.get('view') not in ('angled','top'):reason='view_outside_schema'
                        elif args.get('rotateDegrees') not in (-90,0,90,180):reason='rotation_outside_schema'
                    elif value.get('tool')=='inspect' and isinstance(args.get('manualStep'),str):reason='manualStep_string_instead_of_number'
            except (ValueError,TypeError):reason='truncated_json' if number in truncated else 'non_json'
            invalid.append(dict(decision=number,reason=reason))
        if call.get('modelOutput',{}).get('tool')=='observe' and call.get('environmentOutput',{}).get('code')=='OBSERVED':observations.append(number)
    return dict(runId=result['arenaRunId'],model=result['model'],caseId=result['caseId'],branch=result['arenaBranch'],
        terminal=result['terminalStatus'],success=result['success'],repairApplicable=result['repairApplicable'],
        feedbackCodes=dict(codes),generationTruncatedAt=truncated,invalidOutputs=invalid,freshObserveDecisions=observations,
        stateMetrics=result['stateMetrics'],executionMetrics=result['executionMetrics'],controllerMetrics=result['controllerMetrics'],
        inputMetrics=result['inputMetrics'],providerUsage=result['providerUsage'])


def main():
    report=json.loads((OUT/'pilot.json').read_text());audits=[audit(r) for r in report['runs']]
    write_json(OUT/'case-audit.json',dict(schema='brick-atlas-agent-case-audit/1',runs=audits,
        interpretation='Selected pilot; behavior descriptions, not an identification of internal model failure causes.'))
    rows=['# 统一视觉 Agent：真实试跑结果','',
          '[打开本机回放](http://127.0.0.1:8830/agent) · [实验设计](EXPERIMENTS.zh-CN.md) · [机器可读结果](pilot.json) · [逐题错误统计](case-audit.json)','',
          '所有操作均由 API 模型逐轮决定；没有脚本前缀、GT 提示、自动修复或自动重试。两种物件是预先选定的小样本，不代表全库成绩。','',
          '| 物件 / 分支 | Backbone | 结果 | 轮数 | 动作尝试 / 观察查询 | 结构 F1 | 截断 / 格式错误 |',
          '|---|---|---|---:|---:|---:|---:|']
    for r,a in zip(report['runs'],audits):
        title='搅拌车模块' if '4096-' in r['caseId'] else '小汽车';branch='正常' if r['arenaBranch']=='normal' else '事故'
        status={'service_error':'服务错误，不计能力失败','client_budget_exhausted':'费用停止，不计完整题失败','harness_error':'程序错误'}.get(r['terminalStatus'],'完成' if r['success'] else '未完成')
        c=r['controllerMetrics'];f1=r['stateMetrics'].get('fullPlacement',{}).get('f1')
        rows.append(f"| [{title} / {branch}](http://127.0.0.1:8830/agent?run={r['arenaRunId']}) | {r['model'].split('/')[-1]} | {status} | {r['apiCalls']} | {c['actionAttempts']} / {c['observationRequests']} | {f1:.3f} | {len(a['generationTruncatedAt'])} / {len(a['invalidOutputs'])} |")
    rows+=['','截断和格式错误会重叠：例如输出被截断导致 JSON 不完整。不能把两列相加作为失败总数。','',
           '## 正常前置与事故分母','',
           f"已完成记录 {len(report['runs'])} 条；因正常分支未成功而未运行的事故条件 {len(report.get('notRun',[]))} 个。未运行／未触发不计为漏检或修复失败。",'',
           '## 费用','',
           'OpenRouter 返回的 `usage.cost` 是服务商扣费记录；DeepSeek 与阿里云按返回 token 和当时官方单价估算，不冒充已核对账单。阿里云以人民币单列；为了限制本轮费用，程序保守地把 1 元人民币占用 1 美元预算额度，这不是汇率。','',
           '```json',json.dumps(report.get('ledger',{}),ensure_ascii=False,indent=2),'```','',
           '## 完整记录在哪里','',
           '- `pilot.json`：预先指定的模型、题目、统一预算及全部运行结果。',
           '- `case-audit.json`：逐题截断、格式、工具反馈与评分。',
           '- `../brickplan-dynamic-arena/runs/agent-*/spectator.json`：逐步现场、目标、模型计划、实际收到的图片。',
           '- 同目录 `log.json`：每轮模型输入、输出、环境返回、图片哈希、生成 ID 和用量。',
           '- 同目录 `api/*.request.json.gz`、`*.response.private.json.gz`：含图片字节的原始 API 请求／响应；不含认证头或 API key。',
           '- 同目录 `record.private.json.gz`：评价者专用状态与事故记录；不会进入模型输入。','',
           '## 范围说明','',
           '本次实现的是动态视觉 agent。静态模型与动态直接模型实验均保留，正式三组比较还需相同输入与预算的控制。新的 T/I/TI 适配、同现场视觉记忆分叉、真人盲操作、独立物理验证也仍需补齐。']
    (OUT/'README.zh-CN.md').write_text('\n'.join(rows)+'\n')
    print('Wrote unified-agent report for',len(audits),'runs')


if __name__=='__main__':main()
