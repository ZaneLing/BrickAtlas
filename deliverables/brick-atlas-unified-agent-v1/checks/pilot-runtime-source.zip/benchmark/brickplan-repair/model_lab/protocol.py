"""Visual-only, one-decision-at-a-time grounding; evaluator data stays private."""
import sys,json,math,hashlib,base64,io,random
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path[:0]=[str(HERE.parent),str(HERE.parent/'eval')]
from baseplate import PlateAssembly
from static_v4.metrics import RepairEpisode
from vision import VisionRenderer,_camera,SIZE
from render import triangles,ldraw,C
OUT=ROOT/'deliverables/brickplan-model-lab'
LIB=ROOT/'deliverables/brickplan-static-v4/library/models'
VERSION='visual-grid-bottom-center/1'
FONT=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',22)
SYSTEM='''Repair the current LEGO assembly to match the target pictures. Return JSON with exactly ONE action per reply: {"actions":[{"type":"attach","partId":"A03","position":[2.5,1,3],"rotation":0}],"note":"short reason"}. Other actions: detach with partId; inspect with view (isometric/top/front/rear/left/right/bottom) optionally partId to isolate; finish. Never give a whole plan in actions. Observe execution feedback and the updated images before deciding again.
All scene images are native 1600x1200 RGB. Inventory cards show anonymous handles, part shape and color, and whether each is INSTALLED or IN RACK. IDs are arbitrary and reveal no answer. Use installed handles for detaching, rack handles for attaching. Identical pieces are interchangeable. Inspect with partId gives an isolated CURRENT view (never target correspondence).
POSITION CONVENTION: [x,z,h] is the BOTTOM FACE CENTER of the selected brick in a fixed baseplate coordinate frame. x and z use stud pitch, h uses thin-plate height upward. One stud pitch=20 LDraw units, one thin-plate height=8 LDraw units; a standard brick body is 3 plates high. h=0 is bottom-face contact with the baseplate. Top view: +x right, +z down. Front view: +x right, +h up; looking from positive z. Read coordinate ticks in image margins; all images share the same frame. Negative coordinates allowed. This is NOT a corner, NOT a screen pixel and NOT the top-center LDraw origin. Half-stud centers are allowed. rotation is degrees 0,90,180,270 about the upward axis: at 0 use the inventory shape's canonical axes (also shown in top-view inventory); 90 maps local +x to +z. Workspace x,z in [-6,12], h in [0,18]. No snapping to the goal is performed.
The white infinite baseplate is environment, excluded from inventory. Orthographic images omit its surface to keep assembly silhouettes readable. Install requires compatible connectors, collision-free endpoint and a clear straight insertion path. Detach requires a clear straight extraction path. Connected components may be held; no bottom-support rule. Any legal repair order is accepted. Only finish with feedback SUCCESS certifies completion. Unknown or invalid actions leave the state unchanged. No reference plan, error label, target coordinates or geometry state is provided.'''

def load(case_id):
    model=case_id.split(':')[0];folder=LIB/model
    source=json.loads((folder/'qualification.json').read_text())
    rt=PlateAssembly(source);case=json.loads((folder/'cases.json').read_text())[case_id]
    cert=json.loads((ROOT/'deliverables/brickplan-static-v4'/case['certificate']['file']).read_text())
    return rt,case,RepairEpisode(rt,case,cert)

def bottom(rt,actor):
    vals=ldraw.triangles(rt.parts[actor]['partNumber']+'.dat')[0]
    v=np.concatenate([np.asarray(a).reshape(-1,3) for a in vals.values()]);lo=v.min(0);hi=v.max(0)
    return np.array([(lo[0]+hi[0])/2,hi[1],(lo[2]+hi[2])/2])

def convert(rt,action,reverse):
    kind=action.get('type');internal={'type':kind};ground={}
    if kind not in ('attach','detach','inspect','finish'):raise ValueError('Unknown action type')
    if kind in ('attach','detach'):
        actor=reverse[action['partId']];internal['partId']=actor;ground['actor']=actor
    if kind=='attach':
        p=np.asarray(action['position'],dtype=float);r=action['rotation']
        if p.shape!=(3,) or not np.isfinite(p).all() or isinstance(r,bool) or r not in (0,90,180,270):raise ValueError('Invalid position or rotation')
        if not(-6<=p[0]<=12 and -6<=p[1]<=12 and 0<=p[2]<=18):raise ValueError('Outside workspace')
        a=math.radians(r);rotation=np.array([[math.cos(a),0,-math.sin(a)],[0,1,0],[math.sin(a),0,math.cos(a)]])
        local=np.eye(4);local[:3,:3]=rotation;local[:3,3]=[20*p[0],-8*p[2],20*p[1]]-rotation@bottom(rt,actor)
        raw=rt.board@local;internal['rawMatrix']=raw.tolist()
        center=(rt.board@np.array([20*p[0],-8*p[2],20*p[1],1]))[:3]
        ground.update(position=p.tolist(),rotation=r,anchor='bottom-face-center',worldLDU=center.tolist(),rawMatrix=raw.tolist(),localBottom=bottom(rt,actor).tolist())
    return internal,ground

class Visuals(VisionRenderer):
    def __init__(self,rt):
        self.rt=rt;super().__init__(rt.cert)
        self.geometry={};self.sync()
        # Fixed frame, independent of which actor is faulty or its target pose.
        self.envelope=np.array([[x,y,z] for x in (-120,240) for y in (0,144) for z in (-240,120)])
    def sync(self):
        for k,row in {**self.rt.candidates,**self.rt.extra}.items():
            if k in self.geometry:continue
            p=dict(row['part']);p['rawMatrix']=(self.rt.inverse_board@np.array(p['rawMatrix'])).tolist()
            v,c=triangles(json.dumps(p,sort_keys=True));self.geometry[k]=(v,c)
            lo=v.reshape(-1,3).min(0);hi=v.reshape(-1,3).max(0)
            self.bounds[k]=np.array([[x,y,z] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
    def scene(self,state,view,only=None):
        self.sync();im,_=self.rgb(state,view,only=only,fixtures=False)
        if only:return im
        draw=ImageDraw.Draw(im);cam=lab_camera(view,None);pts=self.envelope@cam;lo=pts.min(0);hi=pts.max(0);ctr=(lo+hi)/2
        scale=min(1600*.88/max(hi[0]-lo[0],1),1200*.88/max(hi[1]-lo[1],1))
        def xy(p):
            q=np.asarray(p)@cam;return ((q[0]-ctr[0])*scale+800,-(q[1]-ctr[1])*scale+600)
        # Ticks only in outer margins: never overlay part IDs or text on geometry.
        if view in ('top','front'):
            for x in range(-6,13):
                u,_=xy([20*x,0,0]);draw.line((u,1143,u,1154),fill='#536575',width=2);draw.text((u-9,1157),str(x),font=FONT,fill='#334455')
            draw.text((1450,1112),'+x (stud)',font=FONT,fill='#334455')
            if view=='top':
                for z in range(-6,13):
                    _,v=xy([0,0,-20*z]);draw.text((16,v-11),str(z),font=FONT,fill='#334455');draw.line((58,v,69,v),fill='#536575',width=2)
                draw.text((15,15),'+z downward (stud)',font=FONT,fill='#334455')
            else:
                for h in range(0,19):
                    _,v=xy([0,8*h,0]);draw.text((16,v-11),str(h),font=FONT,fill='#334455');draw.line((58,v,69,v),fill='#536575',width=2)
                draw.text((15,15),'+h upward (plate)',font=FONT,fill='#334455')
        return im
    def inventory_page(self,state,aliases):
        actors=sorted(aliases,key=aliases.get);im=Image.new('RGB',(1600,math.ceil(len(actors)/4)*320),'white');d=ImageDraw.Draw(im)
        for i,actor in enumerate(actors):
            k=next(k for k,r in self.rt.candidates.items() if r['actor']==actor)
            # Render canonical orientation: zero yaw; inventory does not reveal goal orientation.
            raw=np.eye(4);p=dict(self.rt.parts[actor]);p['rawMatrix']=raw.tolist()
            key='inventory-'+actor;v,c=triangles(json.dumps(p,sort_keys=True));self.geometry[key]=(v,c)
            lo=v.reshape(-1,3).min(0);hi=v.reshape(-1,3).max(0);self.bounds[key]=np.array([[x,y,z] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
            x=i%4*400;y=i//4*320
            for j,view in enumerate(('isometric','top')):
                tile,_=self.rgb({actor:key},view,size=(200,260),frame_keys=[key],fixtures=False);im.paste(tile,(x+j*200,y+45))
            d.text((x+8,y+5),aliases[actor]+' / '+('INSTALLED' if state.get(actor) else 'IN RACK'),font=FONT,fill='#17283a')
            d.text((x+220,y+298),'top: +x right, +z down',font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',14),fill='#536575')
        return im

def lab_camera(view,angles):
    if angles is None and view=='top':return np.array([[1,0,0],[0,0,1],[0,1,0]],float)
    if angles is None and view=='front':return np.diag([1,1,-1.])
    return _camera(view,angles)

def lab_rgb(self, state, view='isometric', size=SIZE, only=None, angles=None,
        crop=None, frame_keys=None, supersample=2, fixtures=True):
    camera = lab_camera(view, angles)
    parts = {**({a:a for a in self.cert['fixed']} if fixtures else {}), **state}
    entries = [(a,k) for a,k in parts.items() if k in self.geometry and (only is None or a==only)]
    if frame_keys is not None:
        envelope = np.concatenate([self.bounds[k] for k in frame_keys if k in self.bounds])
    elif only is not None:
        envelope = np.concatenate([self.bounds[k] for k,r in self.cert['candidates'].items() if r['actor']==only])
    else:
        envelope = self.envelope
    projected = envelope @ camera
    lo, hi = projected.min(0), projected.max(0)
    center = (lo+hi)/2
    w,h = size
    scale = min(w*.88/max(hi[0]-lo[0],1), h*.88/max(hi[1]-lo[1],1))
    # Recompute projection for the requested crop, retaining equal scale
    # and framing for paired images. It is a new render, never upsampling.
    left, top, right, bottom = crop or (0.,0.,1.,1.)
    crop_scale = min(1/(right-left), 1/(bottom-top))
    shift_x = ((left+right)/2-.5)*w
    shift_y = ((top+bottom)/2-.5)*h
    sw,sh = w*supersample,h*supersample
    pixels = np.full((sh,sw,3),246,dtype=np.uint8)
    depth = np.full((sh,sw),-1e20,dtype=np.float32)
    mask = np.zeros((sh,sw),dtype=np.int32)
    if entries:
        vertices=[];colors=[];ids=[]
        for actor,key in entries:
            v,c = self.geometry[key]
            vertices.append(v);colors.append(c);ids.append(np.full(len(v),self.ids[actor],np.int32))
        v = np.concatenate(vertices) @ camera
        v[:,:,0] = (((v[:,:,0]-center[0])*scale-shift_x)*crop_scale+w/2)*supersample
        v[:,:,1] = ((-(v[:,:,1]-center[1])*scale-shift_y)*crop_scale+h/2)*supersample
        v = np.ascontiguousarray(v,dtype=np.float32)
        colors=np.ascontiguousarray(np.concatenate(colors));ids=np.ascontiguousarray(np.concatenate(ids))
        C(len(v),v.ctypes.data,colors.ctypes.data,ids.ctypes.data,sw,sh,pixels.ctypes.data,depth.ctypes.data,mask.ctypes.data)
    # Contact contours reveal stud rims in orthographic views without labels.
    edge=np.zeros((sh,sw),bool)
    for axis in (0,1):
        other=np.roll(depth,1,axis=axis);valid=(depth>-1e19)&(other>-1e19)
        jump=valid & (np.abs(depth-other)>1.2)
        edge |= jump
    pixels[edge]=(pixels[edge].astype(float)*.72).astype('uint8')
    im=Image.fromarray(pixels)
    if supersample>1:
        im=im.resize(size,Image.Resampling.LANCZOS)
        mask=mask[supersample//2::supersample,supersample//2::supersample].copy()
    return im,mask

Visuals.rgb=lab_rgb

def save_image(im):
    buf=io.BytesIO();im.save(buf,format='PNG');data=buf.getvalue();sha=hashlib.sha256(data).hexdigest();folder=OUT/'images';folder.mkdir(parents=True,exist_ok=True)
    (folder/(sha+'.png')).write_bytes(data)
    return {'sha256':sha,'url':'/api/model-lab/images/'+sha+'.png','width':im.width,'height':im.height},data

def observation(rt,ep,renderer,aliases,history,extra=None):
    records=[];content=[]
    obs=dict(protocol=VERSION,task='Repair current to match target, then finish.',actionHandles=list(sorted(aliases.values())),recentFeedback=history[-5:],maxActionsPerResponse=1)
    content.append({'type':'text','text':json.dumps(obs)})
    states=[('current',ep.state),('target',rt.goal)]
    for name,state in states:
        for view in ('isometric','top','front'):
            record,data=save_image(renderer.scene(state,view));record.update(label=name+' / '+view)
            records.append(record);content.extend([{'type':'text','text':record['label']},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(data).decode(),'detail':'high'}}])
    record,data=save_image(renderer.inventory_page(ep.state,aliases));record['label']='inventory / canonical orientation';records.append(record)
    content.extend([{'type':'text','text':record['label']},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(data).decode(),'detail':'high'}}])
    if extra and extra.get('type')=='inspect':
        view=extra.get('view','isometric');actor={v:k for k,v in aliases.items()}.get(extra.get('partId'))
        if view in ('isometric','top','front','rear','left','right','bottom'):
            # General camera inspection includes both scenes; isolated inspection
            # shows current only so an ID cannot reveal its hidden target pose.
            for name,state in ([('current',ep.state)] if actor else states):
                im=renderer.scene(state,view,only=actor) if not actor or state.get(actor) else renderer.inventory_page(ep.state,aliases)
                record,data=save_image(im);record['label']='inspection / '+name+' / '+view+' / '+str(extra.get('partId','all'));records.append(record)
                content.extend([{'type':'text','text':record['label']},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(data).decode(),'detail':'high'}}])
    return {'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':content}]},dict(system=SYSTEM,observation=obs,images=records)


def parse_reply(text):
    """Accept one unambiguous JSON action object, even with prose/fence wrappers.

    Do not infer actions, repair fields, choose between multiple objects, or fill
    coordinates. Preserve the original response and label normalization.
    """
    decoder=json.JSONDecoder()
    try:
        value=json.loads(text)
        if not isinstance(value,dict):raise ValueError('Reply must contain one action object')
        return value,'json'
    except json.JSONDecodeError:pass
    found=[]
    for i,ch in enumerate(text):
        if ch!='{':continue
        try:value,end=decoder.raw_decode(text[i:])
        except json.JSONDecodeError:continue
        if isinstance(value,dict) and 'actions' in value:found.append(value)
    if len(found)!=1:raise ValueError('No unambiguous JSON action object')
    return found[0],'json-extracted-from-wrapper'
