"""Paid visual-only pilot. Immutable per-step evidence; no oracle correction."""
from protocol import *
import subprocess,time,datetime,argparse
MODELS=['openai/gpt-6.1-sol','google/gemini-4-argon','anthropic/claude-sonnet-5.5']
CASES=['sr4-suspended:missing','sr4-shared-1:single-1','sr4-alternative-release:order']
NODE=ROOT/'.tools/node-v22.23.2-darwin-arm64/bin/node'

def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2));temp.replace(path)

def run(cid,model,maxsteps):
    runid=hashlib.sha256((VERSION+cid+model).encode()).hexdigest()[:20];path=OUT/'runs'/(runid+'.json')
    if path.exists():
        previous=json.loads(path.read_text())
        if previous.get('status')!='running':return previous
        raise RuntimeError('Interrupted run exists; inspect paid ledger before resuming')
    rt,case,ep=load(cid);actors=list(rt.actors);random.Random('model-lab-fixed-alias-v1:'+cid.split(':')[0]).shuffle(actors)
    alias={a:f'A{i+1:02d}' for i,a in enumerate(actors)};reverse={v:k for k,v in alias.items()};renderer=Visuals(rt)
    record=dict(id=runid,protocol=VERSION,adapterVersion=2,model=model,modelId=case['modelId'],caseId=cid,title=case['title'],aliases=alias,initial=ep.state.copy(),goal=rt.goal,steps=[],runtimePoses={},status='running',costUSD=0,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),coordinateFrame=dict(matrix=rt.board.tolist(),positionOrder=['x','z','h'],anchor='bottom-face-center',units=[20,20,8],maxSteps=maxsteps))
    dump(path,record);history=[];extra=None
    for i in range(maxsteps):
        request,public=observation(rt,ep,renderer,alias,history,extra);request['model']=model
        before=ep.state.copy();parsed={};parse_mode='invalid';started=time.time();record['pendingStep']=i+1;dump(path,record)
        call=subprocess.run([str(NODE),'--import','tsx',str(HERE/'call_api.ts')],cwd=ROOT,input=json.dumps(request),text=True,capture_output=True,timeout=125)
        if call.returncode:
            # Store only a fixed classification; upstream exceptions can contain request data.
            reason='budget-stop' if 'Budget limit reached' in call.stderr else 'api-error'
            record.update(status=reason,pendingStep=None);dump(path,record);print(json.dumps(dict(run=runid,case=cid,model=model,status=reason)),flush=True)
            if reason=='api-error':raise RuntimeError('API failed; inspect ledger before further calls')
            return record
        result=json.loads(call.stdout);record['costUSD']+=result['cost'];ground={};internal=None;action=None;attempt=before.copy()
        try:
            parsed,parse_mode=parse_reply(result['content']);actions=parsed.get('actions')
            if not isinstance(actions,list) or len(actions)!=1 or not isinstance(actions[0],dict):raise ValueError('Exactly one action is required')
            action=actions[0];internal,ground=convert(rt,action,reverse)
            if internal['type']=='attach':attempt[internal['partId']]=rt.register(internal['partId'],internal['rawMatrix'])
            elif internal['type']=='detach':attempt[internal['partId']]=''
            feedback=ep.step(internal)
        except (ValueError,TypeError,KeyError,IndexError):
            feedback=ep.step({'type':'invalid'});feedback['code']='INVALID_ACTION'
        # State images exist even when model stops, rejects, or runs out of steps.
        afterimages=[]
        for name,state in [('before',before),('attempt',attempt),('after',ep.state)]:
            image,_=save_image(renderer.scene(state,'isometric'));image['label']=name;afterimages.append(image)
        record['steps'].append(dict(index=i+1,input=public,reply=result,parseMode=parse_mode,action=action,internalAction=internal,grounding=ground,before=before,attempt=attempt,after=ep.state.copy(),feedback=feedback,images=afterimages,elapsedSeconds=time.time()-started))
        record.update(runtimePoses=rt.extra,score=ep.score(),pendingStep=None);dump(path,record)
        print(json.dumps(dict(run=runid,case=cid,model=model,step=i+1,action=action,feedback=feedback,cost=round(record['costUSD'],5))),flush=True)
        history.append(dict(action=action,feedback=feedback,note=parsed.get('note','')[:600] if 'parsed' in locals() and isinstance(parsed,dict) else ''))
        extra=action if action and action.get('type')=='inspect' else None
        if ep.finished:break
    record.update(status='success' if ep.success else 'incomplete' if ep.finished else 'step-limit',score=ep.score(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());dump(path,record)
    return record

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--case');parser.add_argument('--model');parser.add_argument('--maxsteps',type=int,default=10);args=parser.parse_args()
    for cid in [args.case] if args.case else CASES:
        for model in [args.model] if args.model else MODELS:
            result=run(cid,model,args.maxsteps)
            if result['status']=='budget-stop':sys.exit(0)
