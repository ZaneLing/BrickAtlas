from protocol import *
CASES=['sr4-suspended:missing','sr4-shared-1:single-1','sr4-alternative-release:order']
results=[]
for cid in CASES:
    rt,case,ep=load(cid);aliases={a:f'A{i+1:02}' for i,a in enumerate(rt.actors)};reverse={v:k for k,v in aliases.items()}
    renderer=Visuals(rt);request,public=observation(rt,ep,renderer,aliases,[])
    for op in case['oraclePlan']:
        action=dict(op);action['partId']=aliases[op['partId']]
        if op['type']=='attach':
            raw=np.asarray(rt.row(op['candidate'])['part']['rawMatrix']);local=rt.inverse_board@raw
            p=local@np.r_[bottom(rt,op['partId']),1];yaw=round(math.degrees(math.atan2(local[2,0],local[0,0])))%360
            action={'type':'attach','partId':aliases[op['partId']],'position':[p[0]/20,p[2]/20,-p[1]/8],'rotation':yaw}
            converted,ground=convert(rt,action,reverse)
            assert np.allclose(converted['rawMatrix'],raw,atol=.001),(cid,raw,converted)
        else:converted,ground=convert(rt,action,reverse)
        feedback=ep.step(converted);assert feedback['code']=='OK',(cid,action,feedback)
    assert ep.step({'type':'finish'})['code']=='SUCCESS'
    results.append(dict(caseId=cid,success=True,actions=ep.records,initialImages=public['images']))
OUT.mkdir(exist_ok=True,parents=True);(OUT/'offline-verification.json').write_text(json.dumps(results,indent=2))
print(json.dumps([{'case':x['caseId'],'success':x['success']} for x in results]))
