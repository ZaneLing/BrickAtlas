"""Replay genuine model outputs; verify grounding, immutable evidence and costs."""
from protocol import *
from collections import Counter
files=[p for p in sorted((OUT/'runs').glob('*.json')) if json.loads(p.read_text()).get('protocol')==VERSION];verified=[];generation_ids=set();images=set()
for path in files:
    run=json.loads(path.read_text());rt,case,ep=load(run['caseId']);reverse={v:k for k,v in run['aliases'].items()}
    for step in run['steps']:
        assert ep.state==step['before']
        parsed,mode=parse_reply(step['reply']['content']);assert len(parsed['actions'])==1
        internal,ground=convert(rt,parsed['actions'][0],reverse)
        assert internal==step['internalAction'] and ground==step['grounding']
        feedback=ep.step(internal);assert feedback==step['feedback']
        assert ep.state==step['after']
        if feedback['code'] not in ('OK','SUCCESS','INCOMPLETE','OBSERVED'):assert step['before']==step['after']
        assert step['input']['observation']['protocol']==VERSION
        assert set(step['input']['observation'])=={'protocol','task','actionHandles','recentFeedback','maxActionsPerResponse'}
        # Private geometry, model goals and case labels never enter observation.
        assert not any(k in step['input'] for k in ('goal','initial','candidates','oraclePlan','roots'))
        assert step['input']['system']==SYSTEM
        assert len(step['input']['images'])>=7
        for im in step['input']['images']+step['images']:
            file=OUT/'images'/(im['sha256']+'.png')
            if file not in images:
                assert hashlib.sha256(file.read_bytes()).hexdigest()==im['sha256'];images.add(file)
            assert im['width']==1600 and (im['height']==1200 or im['label'].startswith('inventory') and im['height']%320==0)
        generation_ids.add(step['reply']['id'])
    assert ep.success and ep.score()==run['score']
    verified.append(dict(id=run['id'],model=run['model'],caseId=run['caseId'],decisions=len(run['steps']),success=ep.success,legalMoves=ep.score()['execution']['legalMoves'],invalidMoves=ep.score()['execution']['invalidMoves'],costUSD=run['costUSD']))
# Exact parsing and anchor convention checks, independent of target coordinates.
assert parse_reply('```json\n{"actions":[{"type":"finish"}]}\n```')[1]=='json-extracted-from-wrapper'
try:parse_reply('{"actions":[]} {"actions":[]}');raise AssertionError('Ambiguous replies accepted')
except ValueError:pass
rt,case,ep=load('sr4-shared-1:single-1');actor=rt.actors[0]
for yaw in (0,90,180,270):
    internal,g=convert(rt,{'type':'attach','partId':'X','position':[2.5,1,3],'rotation':yaw},{'X':actor})
    world=np.asarray(internal['rawMatrix'])@np.r_[bottom(rt,actor),1]
    assert np.allclose(world[:3],g['worldLDU'])
ledger=json.loads((ROOT/'benchmark/.runtime/campaign-ledger.json').read_text())
charges=[c for c in ledger['charges'] if c.get('authorization')=='model-lab-2026-10-15' and not c.get('experiment')]
assert all(c['status']=='settled' for c in charges)
archive=[json.loads(p.read_text()) for p in (OUT/'adapter-audit').glob('*.json')]
allsteps=[s for r in [json.loads(p.read_text()) for p in files]+archive for s in r['steps']]
assert len(allsteps)==len(charges)
bygen={c['generationId']:c for c in charges}
for step in allsteps:assert abs(bygen[step['reply']['id']]['actual']-step['reply']['cost'])<1e-10
spent=sum(c['actual'] for c in charges);assert spent<=4
result=dict(passed=True,runs=verified,uniqueImageFilesVerified=len(images),totalCalls=len(charges),comparisonCalls=sum(r['decisions'] for r in verified),totalCostUSD=spent,comparisonCostUSD=sum(r['costUSD'] for r in verified),adapterAuditCostUSD=sum(r['costUSD'] for r in archive),remainingUSD=4-spent,allChargesSettled=True,checked=['exact replay of model JSON','bottom center at all 4 rotations','ambiguous JSON rejection','execution before/after','all final metrics','input field allowlist','image byte hashes','provider generation IDs and costs'])
(OUT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
