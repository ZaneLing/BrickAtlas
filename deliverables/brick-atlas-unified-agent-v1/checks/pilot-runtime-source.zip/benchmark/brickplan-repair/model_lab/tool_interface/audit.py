from run import *
from interface import decode,ContractError
from interface_v1 import Executor as LegacyExecutor,ContractError as LegacyError
verified=[];images=set();calls=[]
allruns=[json.loads(p.read_text()) for p in (OUT/'runs').glob('*.json')]
for run in allruns:
    if not run.get('protocol','').startswith('visual-native-tools/'):continue
    current=run['protocol']==TOOL_VERSION
    rt,case,ep=load(run['caseId']);executor=(Executor if current else LegacyExecutor)(ep,run['aliases'])
    assert run['toolSchemas']==executor.tools
    history=[];schema_errors=0
    for step in run['steps']:
        req=step['input']['request'];chat='messages' in req
        actual_tools=[dict(type='function',**t['function']) for t in req['tools']] if chat else req['tools']
        assert actual_tools==executor.tools and req['parallel_tool_calls'] is False
        assert req['tool_choice']==('auto' if run['model'].startswith('anthropic/') else 'required')
        previous=[x for x in req.get('input',req.get('messages',[])) if x.get('type')=='function_call_output' or x.get('role')=='tool']
        assert len(previous)==len(history)
        assert step['before']==ep.state
        try:
            executed=executor.execute(step['reply']['output'],step['input']['observation']['state_revision']) if current else executor.execute(step['reply']['output'])
            assert step['schemaValid'] is True and executed['toolResult']==step['toolResult']
            assert step['action']==executed['action'] and step['internalAction']==executed['internalAction'] and step['grounding']==executed['grounding']
        except (ContractError,LegacyError) as error:
            schema_errors+=1;assert step['schemaValid'] is False and str(error)==step['feedback']['code'] and step['before']==step['after']
        assert ep.state==step['after']
        history.append(step['nativeToolCalls']);calls.append(step['reply'])
        for im in step['input']['images']+step['images']:
            f=OUT/'images'/(im['sha256']+'.png')
            if f not in images:assert hashlib.sha256(f.read_bytes()).hexdigest()==im['sha256'];images.add(f)
    assert ep.score()==run['score']
    assert schema_errors==run['interfaceMetrics']['schemaErrors']
    old=next(r for r in allruns if r.get('protocol')=='visual-grid-bottom-center/1' and r['model']==run['model'] and r['caseId']==run['caseId'])
    assert run['steps'][0]['input']['images']==old['steps'][0]['input']['images']
    verified.append(dict(id=run['id'],protocol=run['protocol'],model=run['model'],status=run['status'],responses=len(run['steps']),schemaErrors=schema_errors,staleActions=run['interfaceMetrics']['staleActions'],legalMoves=run['score']['execution']['legalMoves'],invalidMoves=run['score']['execution']['invalidMoves'],observations=run['score']['execution']['observations'],costUSD=run['costUSD'],sameInitialImagesAsPrevious=True))
final=[r for r in verified if r['protocol']==TOOL_VERSION]
assert len(final)==3 and len({r['model'] for r in final})==3
ledger=json.loads((ROOT/'benchmark/.runtime/campaign-ledger.json').read_text());charges=[c for c in ledger['charges'] if c.get('experiment')=='native-tools-single-case-v1'];assert all(c['status']=='settled' for c in charges)
bygen={c['generationId']:c for c in charges if c.get('generationId')}
for c in calls:assert abs(c['cost']-bygen[c['id']]['actual'])<1e-10
assert len(calls)==len(bygen)
actual=sum(c['actual'] for c in charges);assert actual<=1.5
result=dict(passed=True,finalRuns=final,allRuns=verified,finalSchemaErrors=sum(x['schemaErrors'] for x in final),finalCostsUSD=sum(r['costUSD'] for r in final),accountedCostUSD=actual,routingSetupAttempts=sum(not c.get('generationId') for c in charges),routingSetupCostUpperBoundUSD=sum(c['actual'] for c in charges if not c.get('generationId')),originalAuthorizationSpentUSD=sum(c['actual'] for c in ledger['charges'] if c.get('authorization')=='model-lab-2026-10-15'),uniqueImagesVerified=len(images),allChargesSettled=True,notes=['Native function_call/tool_calls only; prose never parsed as actions','All runs use the same case and identical initial RGB as the previous trial','Requested strict:true on all schemas; local Draft202012 validation before execution','Gateway strict enforcement cannot be independently verified; v1 Gemini emitted invalid empty arguments','v2 revision binding is host-owned; no model-generated concurrency fields','Tool call/output history retained; old visual inputs explicitly omitted in favor of latest state'])
dump(EVIDENCE/'verification.json',result);print(json.dumps(result,ensure_ascii=False))
