"""Provider-neutral native function schemas and authoritative dispatcher."""
import sys,json,math
from pathlib import Path
from copy import deepcopy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from protocol import convert
from jsonschema import Draft202012Validator
VERSION='visual-native-tools/1'
SYSTEM='''Repair the CURRENT LEGO assembly to match the TARGET pictures. Use exactly one native function call per turn, then wait for the tool result and updated images before deciding again. Do not encode actions in prose or a markdown block. Use finish_repair when done; only its SUCCESS result certifies completion.
Inventory images show anonymous piece handles, canonical shape/orientation, color and whether each is INSTALLED or IN RACK. Handles reveal no target position. Identical pieces are interchangeable. Infer the repair from the images; no error labels or target coordinates are provided.
For attach_brick, position is the BOTTOM FACE CENTER, not a corner or the top-center LDraw origin. x_stud and z_stud are fixed baseplate coordinates in stud pitches (20 LDU). height_plate measures upward from the baseplate in thin-plate heights (8 LDU); a normal brick body is 3 plates tall. Read the margin ticks: top view +x right, +z down; front view +x right and height up. yaw_deg=0 uses the inventory's canonical orientation; 90 turns local +x toward baseplate +z. To reorient an installed piece, detach then attach with the desired yaw; there is no collision-bypassing in-place rotation. Coordinates are used exactly without snapping to the target.
Current and target views have a fixed common frame. Images are native 1600x1200; inventory cards are separate. Orthographic views omit the white infinite baseplate surface for visibility; it still exists in the executor. Use inspect_assembly for other camera views. Part isolation reveals CURRENT only, never that instance's target pose.
Connections, endpoint collisions and straight insertion/extraction paths are checked. Held connected components are allowed; no bottom-support rule. Any legal repair order is accepted. A failed action leaves the state unchanged. Use the state_revision supplied in the latest observation.''' 

def obj(properties):return dict(type='object',properties=properties,required=list(properties),additionalProperties=False)
def schemas(handles):
    handle=dict(type='string',enum=sorted(handles),description='Anonymous handle from inventory images.')
    revision=dict(type='integer',minimum=0,description='state_revision from latest observation; guards against stale actions.')
    position=obj(dict(x_stud=dict(type='number',minimum=-6,maximum=12,description='Bottom center x in stud pitches; top view right.'),z_stud=dict(type='number',minimum=-6,maximum=12,description='Bottom center z in stud pitches; top view down.'),height_plate=dict(type='number',minimum=0,maximum=18,description='Bottom center height above the baseplate in plate heights.')))
    def tool(name,description,properties):return dict(type='function',name=name,description=description,strict=True,parameters=obj(properties))
    return [
        tool('attach_brick','Install a rack piece at the explicit bottom-center position and yaw. Validates connectors, collisions and insertion path before changing state. Does not choose a target position.',dict(part_id=handle,position=position,yaw_deg=dict(type='integer',enum=[0,90,180,270],description='Yaw around upward axis; 90 maps local +x to +z.'),state_revision=revision)),
        tool('detach_brick','Remove an installed piece to the rack if a straight extraction path exists. Held connected components are allowed. A blocked removal does not change state.',dict(part_id=handle,state_revision=revision)),
        tool('inspect_assembly','Get a camera view of current and target. With part_id, isolate only that current piece. Does not manipulate pieces or reveal target correspondence.',dict(view=dict(type='string',enum=['isometric','top','front','rear','left','right','bottom']),part_id=dict(type=['string','null'],enum=sorted(handles)+[None],description='Null for whole scenes; anonymous handle to isolate current piece.'),state_revision=revision)),
        tool('finish_repair','Submit the current assembly for final physical equivalence evaluation. Closes the episode. SUCCESS means complete; INCOMPLETE means the episode ended without a correct repair.',dict(state_revision=revision))]

class ContractError(ValueError):pass

def decode(output,tools):
    calls=[x for x in output if x.get('type')=='function_call']
    if len(calls)!=1:raise ContractError('EXPECTED_ONE_NATIVE_FUNCTION_CALL')
    call=calls[0]
    if not isinstance(call.get('call_id'),str) or not call['call_id']:raise ContractError('MISSING_CALL_ID')
    schema=next((t for t in tools if t['name']==call.get('name')),None)
    if not schema:raise ContractError('UNKNOWN_TOOL')
    def reject_constant(x):raise ContractError('NONFINITE_NUMBER')
    def pairs(xs):
        result={}
        for k,v in xs:
            if k in result:raise ContractError('DUPLICATE_ARGUMENT_KEY')
            result[k]=v
        return result
    try:args=json.loads(call['arguments'],parse_constant=reject_constant,object_pairs_hook=pairs)
    except (ValueError,KeyError,TypeError):raise ContractError('INVALID_ARGUMENT_JSON')
    # jsonschema numeric ranges alone do not reject every nonfinite Python number.
    def finite(v):
        if isinstance(v,float) and not math.isfinite(v):raise ContractError('NONFINITE_NUMBER')
        if isinstance(v,dict):
            for x in v.values():finite(x)
        if isinstance(v,list):
            for x in v:finite(x)
    finite(args)
    errors=list(Draft202012Validator(schema['parameters']).iter_errors(args))
    if errors:raise ContractError('SCHEMA_VALIDATION_FAILED')
    name=call['name'];action={'type':{'attach_brick':'attach','detach_brick':'detach','inspect_assembly':'inspect','finish_repair':'finish'}[name]}
    if args.get('part_id') is not None:action['partId']=args['part_id']
    if name=='attach_brick':action.update(position=[args['position'][k] for k in ('x_stud','z_stud','height_plate')],rotation=args['yaw_deg'])
    if name=='inspect_assembly':action['view']=args['view']
    return call,args,action

class Executor:
    def __init__(self,ep,aliases):
        self.ep=ep;self.reverse={v:k for k,v in aliases.items()};self.tools=schemas(aliases.values());self.revision=0;self.seen={}
    def execute(self,output):
        call,args,action=decode(output,self.tools);cid=call['call_id'];token=(call['name'],json.dumps(args,sort_keys=True))
        if cid in self.seen:
            oldtoken,result=self.seen[cid]
            if token!=oldtoken:raise ContractError('CALL_ID_REUSED_WITH_DIFFERENT_ARGUMENTS')
            return {**deepcopy(result),'duplicate':True}
        if args['state_revision']!=self.revision:
            result=dict(action=action,internalAction=None,grounding={},toolResult=dict(ok=False,code='STALE_STATE',applied=False,state_revision=self.revision),duplicate=False)
        else:
            internal,ground=convert(self.ep.runtime,action,self.reverse)
            if action['type']=='inspect':internal.update(view=action['view'])
            feedback=self.ep.step(internal);applied=action['type'] in ('attach','detach') and feedback['code']=='OK'
            if applied:self.revision+=1
            result=dict(action=action,internalAction=internal,grounding=ground,toolResult=dict(ok=feedback['code'] in ('OK','OBSERVED','SUCCESS'),code=feedback['code'],applied=applied,state_revision=self.revision),duplicate=False)
        self.seen[cid]=(token,deepcopy(result));return result
