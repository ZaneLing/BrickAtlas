from interface import *
from protocol import load,bottom,np
from jsonschema import Draft202012Validator
rt,case,ep=load('sr4-shared-1:single-1');aliases={a:f'A{i+1:02}' for i,a in enumerate(rt.actors)};executor=Executor(ep,aliases)
for t in executor.tools:Draft202012Validator.check_schema(t['parameters'])
def call(name,args,id='test'):return [dict(type='function_call',call_id=id,name=name,arguments=json.dumps(args))]
errors=0
base=dict(part_id=aliases[rt.actors[0]],position=dict(x_stud=2.5,z_stud=1,height_plate=3),yaw_deg=0)
for bad in [dict(base,yaw_deg=45),dict(base,yaw_deg='90'),dict(base,part_id='UNKNOWN'),dict(base,extra='text'),dict(base,position=dict(x_stud='2.5',z_stud=1,height_plate=3)),dict(base,position=dict(x_stud=0,z_stud=1,height_plate=float('nan'))),dict(base,position=dict(x_stud=0,z_stud=1,height_plate=-1))]:
    try:decode(call('attach_brick',bad),executor.tools);raise AssertionError('Invalid args accepted')
    except ContractError:errors+=1
for text in ['{"state_revision":0,"state_revision":0}','explanation {"state_revision":0}']:
    try:decode([dict(type='function_call',call_id='x',name='finish_repair',arguments=text)],executor.tools);raise AssertionError('Malformed arguments accepted')
    except ContractError:errors+=1
try:decode([dict(type='message',content='{"actions":[]}')],executor.tools);raise AssertionError('Prose accepted as action')
except ContractError:errors+=1
before=ep.state.copy();result=executor.execute(call('detach_brick',dict(part_id=aliases['P001']),'stale'),99);assert result['toolResult']['code']=='STALE_STATE' and before==ep.state
for i,op in enumerate(case['oraclePlan']):
    args=dict(part_id=aliases[op['partId']])
    if op['type']=='attach':
        raw=np.asarray(rt.row(op['candidate'])['part']['rawMatrix']);local=rt.inverse_board@raw;p=local@np.r_[bottom(rt,op['partId']),1]
        args.update(position=dict(x_stud=p[0]/20,z_stud=p[2]/20,height_plate=-p[1]/8),yaw_deg=round(math.degrees(math.atan2(local[2,0],local[0,0])))%360)
    native=call(op['type']+'_brick',args,'action-'+str(i));result=executor.execute(native,executor.revision);assert result['toolResult']['code']=='OK'
    state=ep.state.copy();rev=executor.revision;duplicate=executor.execute(native,executor.revision);assert duplicate['duplicate'] and ep.state==state and executor.revision==rev
assert executor.execute(call('finish_repair',dict(),'finish'),executor.revision)['toolResult']['code']=='SUCCESS'
print(json.dumps(dict(passed=True,malformedRejected=errors,staleGuard=True,idempotent=True,referenceReplaySuccess=True)))
