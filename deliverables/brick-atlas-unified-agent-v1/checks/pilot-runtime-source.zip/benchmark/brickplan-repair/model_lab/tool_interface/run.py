"""One static case, three VLMs, native strict tools. Uses remaining authorization."""
from interface import Executor,ContractError,VERSION as TOOL_VERSION,SYSTEM as TOOL_SYSTEM,schemas
from protocol import *
import subprocess,datetime,time,argparse
ROOT=HERE.parents[2]
TOOLS_HERE=Path(__file__).resolve().parent
EVIDENCE=OUT/'tool-calling'
CASE='sr4-shared-1:single-1'
MODELS=['openai/gpt-6.1-sol','google/gemini-4-argon','anthropic/claude-sonnet-5.5']
NODE=ROOT/'.tools/node-v22.23.2-darwin-arm64/bin/node'

def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2));tmp.replace(path)

def observation_request(rt,ep,visuals,aliases,executor,model,history,extra):
    old,public=observation(rt,ep,visuals,aliases,[],extra)
    obs=public['observation'];obs.update(protocol=TOOL_VERSION,state_revision=executor.revision)
    public['system']=TOOL_SYSTEM
    content=[dict(type='input_text',text=json.dumps(obs))]
    for part in old['messages'][1]['content'][1:]:
        if part['type']=='text':content.append(dict(type='input_text',text=part['text']))
        else:content.append(dict(type='input_image',image_url=part['image_url']['url'],detail='high'))
    chat=model.startswith('google/')
    provider=dict(sort='price',allow_fallbacks=False,require_parameters=False,data_collection='deny',max_price=dict(prompt=2,completion=10,image=.005))
    if chat:
        chat_content=[dict(type='text',text=json.dumps(obs))]+deepcopy(old['messages'][1]['content'][1:])
        user=dict(role='user',content=chat_content)
        body=dict(model=model,messages=[dict(role='system',content=TOOL_SYSTEM)]+history+[user],tools=[dict(type='function',function={k:v for k,v in t.items() if k!='type'}) for t in executor.tools],tool_choice='required',parallel_tool_calls=False,max_tokens=2048,reasoning=dict(effort='low'),provider=provider)
        history_user=dict(role='user',content=json.dumps(obs)+'\n[Prior images omitted; use the latest current/target images.]')
    else:
        user=dict(type='message',role='user',content=content)
        body=dict(model=model,instructions=TOOL_SYSTEM,input=history+[user],tools=executor.tools,tool_choice='auto' if model.startswith('anthropic/') else 'required',parallel_tool_calls=False,store=False,max_output_tokens=2048,reasoning=dict(effort='low'),include=['reasoning.encrypted_content'],provider=provider)
        history_user=deepcopy(user);history_user['content']=[dict(type='input_text',text=json.dumps(obs)+'\n[Prior images omitted; use the latest current/target images.]')]
    display=deepcopy(body);ims=iter(public['images'])
    for item in display.get('input',display.get('messages',[])):
        if isinstance(item.get('content'),list):
            for part in item['content']:
                if part.get('type')=='input_image':part['image_url']=next(ims)['url']
                elif part.get('type')=='image_url':part['image_url']['url']=next(ims)['url']
    transport='chat-completions' if chat else 'responses'
    public.update(request=display,transport=transport,requestRepresentation='Only image data URLs are replaced by local PNG URLs. All text, schema, tool history, and tool results are exact.')
    return dict(protocol=TOOL_VERSION,transport=transport,body=body),public,history_user

from copy import deepcopy

def run(model,maxsteps=8):
    rt,case,ep=load(CASE);actors=list(rt.actors);random.Random('model-lab-fixed-alias-v1:'+CASE.split(':')[0]).shuffle(actors)
    aliases={a:f'A{i+1:02d}' for i,a in enumerate(actors)};executor=Executor(ep,aliases);visuals=Visuals(rt)
    runid=hashlib.sha256((TOOL_VERSION+CASE+model).encode()).hexdigest()[:20];path=OUT/'runs'/(runid+'.json')
    if path.exists():
        old=json.loads(path.read_text())
        if old['status']=='running':raise RuntimeError('Interrupted native run exists; inspect before resuming')
        return old
    record=dict(id=runid,protocol=TOOL_VERSION,transport='openrouter-chat-completions' if model.startswith('google/') else 'openrouter-responses',model=model,modelId=case['modelId'],caseId=CASE,title=case['title']+' · 工具 v2',aliases=aliases,initial=ep.state.copy(),goal=rt.goal,steps=[],runtimePoses={},status='running',costUSD=0,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),coordinateFrame=dict(matrix=rt.board.tolist(),anchor='bottom-face-center',positionFields=['x_stud','z_stud','height_plate'],units=[20,20,8]),toolSchemas=executor.tools,interfaceMetrics=dict(nativeCalls=0,schemaErrors=0,staleActions=0,duplicates=0))
    dump(EVIDENCE/'tools.json',executor.tools);dump(path,record);history=[];extra=None
    for i in range(maxsteps):
        request,public,history_user=observation_request(rt,ep,visuals,aliases,executor,model,history,extra)
        record['pendingStep']=i+1;record['pendingInput']=public;dump(path,record);before=ep.state.copy();start=time.time()
        proc=subprocess.run([str(NODE),'--import','tsx',str(TOOLS_HERE/'call_api.ts')],cwd=ROOT,input=json.dumps(request),text=True,capture_output=True,timeout=125)
        if proc.returncode:
            reason='budget-stop' if 'Budget limit reached' in proc.stderr else 'api-error'
            record.update(status=reason,pendingStep=None);dump(path,record);print(json.dumps(dict(model=model,status=reason)),flush=True)
            raise RuntimeError('API stopped; inspect ledger before further calls')
        reply=json.loads(proc.stdout);record['costUSD']+=reply['cost'];attempt=before.copy();valid=True
        try:
            execution=executor.execute(reply['output'],public['observation']['state_revision']);record['interfaceMetrics']['nativeCalls']+=1
            if execution['toolResult']['code']=='STALE_STATE':record['interfaceMetrics']['staleActions']+=1
            if execution['duplicate']:record['interfaceMetrics']['duplicates']+=1
            internal=execution['internalAction']
            if internal and internal['type']=='attach':attempt[internal['partId']]=rt.register(internal['partId'],internal['rawMatrix'])
            elif internal and internal['type']=='detach':attempt[internal['partId']]=''
        except ContractError as error:
            valid=False;record['interfaceMetrics']['schemaErrors']+=1
            execution=dict(action=None,internalAction=None,grounding={},toolResult=dict(ok=False,code=str(error),applied=False,state_revision=executor.revision))
        images=[]
        for name,state in [('before',before),('attempt',attempt),('after',ep.state)]:
            im,_=save_image(visuals.scene(state,'isometric'));im['label']=name;images.append(im)
        toolcalls=[x for x in reply['output'] if x.get('type')=='function_call']
        record['steps'].append(dict(index=i+1,input=public,reply=reply,parseMode='native-function-call',nativeToolCalls=toolcalls,action=execution['action'],internalAction=execution['internalAction'],grounding=execution['grounding'],before=before,attempt=attempt,after=ep.state.copy(),feedback=dict(code=execution['toolResult']['code']),toolResult=execution['toolResult'],schemaValid=valid,images=images,elapsedSeconds=time.time()-start))
        record.pop('pendingInput',None);record.update(runtimePoses=rt.extra,score=ep.score(),pendingStep=None);dump(path,record)
        print(json.dumps(dict(run=runid,model=model,step=i+1,calls=toolcalls,feedback=execution['toolResult'],costUSD=record['costUSD'])),flush=True)
        if not valid:
            record['status']='interface-error';break # Do not repeatedly pay for the same format failure.
        history.append(history_user)
        if model.startswith('google/'):
            history.append(reply['assistantMessage'])
            history.append(dict(role='tool',tool_call_id=toolcalls[0]['call_id'],content=json.dumps(execution['toolResult'])))
        else:
            history.extend(reply['output'])
            history.append(dict(type='function_call_output',call_id=toolcalls[0]['call_id'],output=json.dumps(execution['toolResult'])))
        extra=execution['action'] if execution['action'] and execution['action']['type']=='inspect' else None
        if ep.finished:break
    record.update(status='success' if ep.success else record['status'] if record['status']=='interface-error' else 'incomplete' if ep.finished else 'step-limit',score=ep.score(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());dump(path,record)
    return record

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=MODELS);args=parser.parse_args()
    for model in [args.model] if args.model else MODELS:run(model)
