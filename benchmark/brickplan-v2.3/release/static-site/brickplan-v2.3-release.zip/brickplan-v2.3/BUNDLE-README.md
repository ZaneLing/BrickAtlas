# BrickPlan 2.3 evaluator/runtime bundle

This archive runs the frozen evaluator and original-geometry practice UI. It is not a complete source-construction checkout.

Install benchmark/brickplan-v2.3/requirements.txt, then run `python benchmark/brickplan-v2.3/server.py serve --port 8783`.

Read paper.pdf and supplement.pdf under benchmark/brickplan-v2.3. The complete editable manuscript is in deliverables/brickplan-paper/brickplan-cvpr-overleaf.zip.

Rebuilding candidate admissions or fully rerunning source-provenance audits requires the matching git source checkout, including assets-source/brickplan-v23, the locked LDraw library, web/public/models/v23-* manifests/provenance, construction geometry dependencies and the archived data/source-intake records. Raw source assets are not promised by this runtime bundle.

questions.jsonl contains practice-only catalogue/provenance metadata. Policy inputs are the publicInputJSON records or authoritative observation API; do not expose cohort, source, stable ID or scoring metadata to evaluated policies.
