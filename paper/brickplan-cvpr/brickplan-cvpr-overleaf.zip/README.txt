Select main.tex or supplement.tex as the root document.
Use pdfLaTeX/BibTeX or Tectonic. Figures are already included.
CVPR 2026 official style; 2027 venue/year label remains a draft.
Replace Draft with the assigned submission ID before submission.
Dataset/metrics snapshot: 25 October 2026.
5,720 distinct tasks; 5,452 main candidates; 268 diagnostic dynamic tasks.
Formal model and current-interface human experiments are not yet complete.
