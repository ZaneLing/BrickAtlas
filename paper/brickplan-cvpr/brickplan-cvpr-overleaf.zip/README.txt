Select main.tex or supplement.tex as the root document.
Use pdfLaTeX/BibTeX or Tectonic. Figures are already included.
CVPR 2026 official style; 2027 venue/year label remains a draft.
Replace Draft with the assigned submission ID before submission.
Dataset/metrics snapshot: 29 October 2026.
310 runnable objects; 4,685 checked questions: 1,600 static + 3,085 dynamic.
Normal-qualified recovery uses independent runs; causal forks remain a planned study.
Formal model and current-interface human experiments are not yet complete.
