Select main.tex or supplement.tex as the root document.
Use pdfLaTeX/BibTeX or Tectonic. Figures are already included.
CVPR 2026 official style; 2027 venue/year label remains a draft.
Replace Draft with the assigned submission ID before submission.
Formal model and human experiments are not yet complete.
